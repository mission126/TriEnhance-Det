import os
import pandas as pd
import numpy as np

# --------------------------
# 配置参数（完全匹配实际列名的空格）
# --------------------------
exp_folders = [
    "/mnt/workspace/ACS-YOLO/runs/detect/runs/train/yolov10n-ADown-C2f_RVB_EMA_run1_seed42",
    "/mnt/workspace/ACS-YOLO/runs/detect/runs/train/yolov10n-ADown-C2f_RVB_EMA_run2_seed123",
    "/mnt/workspace/ACS-YOLO/runs/detect/runs/train/yolov10n-ADown-C2f_RVB_EMA_run3_seed456",
    "/mnt/workspace/ACS-YOLO/runs/detect/runs/train/yolov10n-ADown-C2f_RVB_EMA_run4_seed789",
    "/mnt/workspace/ACS-YOLO/runs/detect/runs/train/yolov10n-ADown-C2f_RVB_EMA_run5_seed1000"
]

# 关键：复制实际列名（包含开头的所有空格）
metrics_names = [
    "   metrics/precision(B)",  # 索引4的实际列名（3个空格）
    "      metrics/recall(B)",  # 索引5的实际列名（4个空格）
    "       metrics/mAP50(B)",  # 索引6的实际列名（5个空格）
    "    metrics/mAP50-95(B)"   # 索引7的实际列名（4个空格）
]

# --------------------------
# 读取并处理数据
# --------------------------
all_best_metrics = []

for i, exp_path in enumerate(exp_folders, 1):
    if not os.path.exists(exp_path):
        raise FileNotFoundError(f"第{i}次训练文件夹不存在：{exp_path}")
    
    csv_path = os.path.join(exp_path, "results.csv")
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"第{i}次训练的指标文件不存在：{csv_path}")
    
    df = pd.read_csv(csv_path)
    
    # 检查列名是否存在
    missing_cols = [col for col in metrics_names if col not in df.columns]
    if missing_cols:
        print(f"\n第{i}次训练CSV的实际列名：")
        for idx, col in enumerate(df.columns):
            print(f"  索引{idx}: '{col}'")
        raise ValueError(f"第{i}次训练的CSV缺少列：{missing_cols}，请核对空格数量")
    
    # 找到最佳轮次（mAP50最高）
    best_idx = df[metrics_names[2]].idxmax()  # 用实际列名定位mAP50
    best_metrics = df.loc[best_idx, metrics_names].to_dict()
    
    # 打印当前训练的最佳指标（去掉空格，整洁显示）
    print(f"第{i}次训练最佳指标：")
    for key, val in best_metrics.items():
        print(f"  {key.strip()}: {val:.4f}")  # strip()去除首尾空格
    all_best_metrics.append(best_metrics)
    print("-" * 50)

# --------------------------
# 计算平均值和标准差
# --------------------------
metrics_df = pd.DataFrame(all_best_metrics)
# 重命名列名（去掉空格，方便后续处理）
metrics_df.columns = [col.strip() for col in metrics_df.columns]
avg_metrics = metrics_df.mean()
std_metrics = metrics_df.std()

# --------------------------
# 输出最终结果
# --------------------------
print("\n" + "=" * 60)
print("5次训练的验证集平均指标（±标准差）：")
name_map = {
    "metrics/precision(B)": "P",
    "metrics/recall(B)": "R",
    "metrics/mAP50(B)": "mAP50",
    "metrics/mAP50-95(B)": "mAP50-95"
}
for col in metrics_df.columns:
    print(f"{name_map[col].ljust(10)}: {avg_metrics[col]:.4f} ± {std_metrics[col]:.4f}")
print("=" * 60)