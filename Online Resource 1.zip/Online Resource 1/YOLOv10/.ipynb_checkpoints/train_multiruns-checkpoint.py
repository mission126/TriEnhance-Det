# 第1部分：导入需要的工具
import torch
import numpy as np
import random
from ultralytics import YOLO  # 导入YOLOv10
import os


# 第2部分：固定随机种子的函数（保证每次训练的随机性可控）
def set_seed(seed):
    torch.manual_seed(seed)  # 固定PyTorch的随机种子
    torch.cuda.manual_seed(seed)  # 固定GPU的随机种子
    np.random.seed(seed)  # 固定numpy的随机种子
    random.seed(seed)  # 固定Python的随机种子
    torch.backends.cudnn.deterministic = True  # 禁用GPU算法自动选择
    torch.backends.cudnn.benchmark = False
    os.environ['PYTHONHASHSEED'] = str(seed)  # 固定环境变量的种子


# 第3部分：多次训练的主函数（统计P、R、mAP50、mAP50-95）
def train_multiruns():
    # ********** 你需要修改的参数（必看！）**********
    model_type = "/mnt/workspace/ACS-YOLO/ultralytics/cfg/models/v10/yolov10n-ADown-C2f_RVB_EMA-CSPHet"  # 模型类型：nano版（小快），可选s/m/l/x（越来越大）
    data_path = "/mnt/workspace/ACS-YOLO/dataset/data.yaml"  # 替换成你的dataset.yaml路径
    num_runs = 5  # 训练次数（新手先试3次，熟练后改5次）
    epochs = 300  # 每次训练的轮数（新手先试50轮，不够再加）
    imgsz = 640  # 图片尺寸（保持640即可）
    # ********************************************

    # 存储每次训练的4个指标（扩展为P、R、mAP50、mAP50-95）
    precision_list = []  # 精确率P
    recall_list = []     # 召回率R
    mAP50_list = []      # mAP50
    mAP50_95_list = []   # mAP50-95
    #seeds = [42, 123, 456]  # 随机种子（数量和num_runs一致）
    seeds = [42, 123, 456, 789, 1000]

    # 循环执行多次训练
    for run in range(num_runs):
        print(f"\n===== 第 {run + 1}/{num_runs} 次训练开始 =====")

        # 1. 设置当前训练的随机种子
        set_seed(seeds[run])

        # 2. 加载YOLOv10模型（每次训练都重新加载，保证独立）
        model = YOLO(f"{model_type}.yaml")  # 从头训练（用模型配置文件）
        # 如果想基于预训练权重训练，替换成：model = YOLO(f"{model_type}.pt")

        # 3. 定义训练结果保存路径（避免覆盖）
        # 修复路径过长问题：取model_type的最后一部分（如"yolov10n"）作为模型名前缀
        model_name = os.path.basename(model_type)
        save_dir = f"runs/train/{model_name}_run{run + 1}_seed{seeds[run]}"

        # 4. 开始训练
        results = model.train(
            data=data_path,  # 数据集配置文件
            epochs=epochs,  # 训练轮数
            imgsz=imgsz,  # 图片尺寸
            device=0,  # 0表示用第1个GPU，没有GPU改"cpu"（慢）
            project="runs/detect",  # 结果总文件夹
            name=save_dir,  # 本次训练的子文件夹
            seed=seeds[run],  # YOLO内部的随机种子
            exist_ok=True  # 允许覆盖已有文件夹
        )

        # 5. 提取本次训练的最佳指标（修复数组转换问题）
        # 核心修改：用np.mean()取平均（适配多维度数组），再转成Python数值
        best_precision = np.mean(results.box.p).item()  # 精确率P（取所有类别的平均值）
        best_recall = np.mean(results.box.r).item()     # 召回率R（取所有类别的平均值）
        best_mAP50 = results.box.map50.item()           # mAP50（本身是单数值，直接转换）
        best_mAP50_95 = results.box.map.item()          # mAP50-95（本身是单数值，直接转换）

        # 6. 保存指标到对应列表
        precision_list.append(best_precision)
        recall_list.append(best_recall)
        mAP50_list.append(best_mAP50)
        mAP50_95_list.append(best_mAP50_95)

        # 打印本次训练结果
        print(f"第 {run + 1} 次训练结果：")
        print(f"P（精确率）={best_precision:.4f}，R（召回率）={best_recall:.4f}")
        print(f"mAP50={best_mAP50:.4f}，mAP50-95={best_mAP50_95:.4f}")

    # 第4部分：计算4个指标的均值和标准差
    # P（精确率）
    mean_p = np.mean(precision_list)
    std_p = np.std(precision_list, ddof=1)  # ddof=1：样本标准差
    # R（召回率）
    mean_r = np.mean(recall_list)
    std_r = np.std(recall_list, ddof=1)
    # mAP50
    mean_map50 = np.mean(mAP50_list)
    std_map50 = np.std(mAP50_list, ddof=1)
    # mAP50-95
    mean_map50_95 = np.mean(mAP50_95_list)
    std_map50_95 = np.std(mAP50_95_list, ddof=1)

    # 打印最终统计结果
    print("\n===== 多次训练统计结果 =====")
    print(f"P（精确率）：均值={mean_p:.4f}，标准差={std_p:.4f} → 格式：{mean_p:.3f}±{std_p:.3f}")
    print(f"R（召回率）：均值={mean_r:.4f}，标准差={std_r:.4f} → 格式：{mean_r:.3f}±{std_r:.3f}")
    print(f"mAP50：均值={mean_map50:.4f}，标准差={std_map50:.4f} → 格式：{mean_map50:.3f}±{std_map50:.3f}")
    print(f"mAP50-95：均值={mean_map50_95:.4f}，标准差={std_map50_95:.4f} → 格式：{mean_map50_95:.3f}±{std_map50_95:.3f}")

    # 保存结果到文件（在当前文件夹生成result.txt）
    with open("result.txt", "w") as f:
        f.write(f"P（精确率）: {mean_p:.3f}±{std_p:.3f}\n")
        f.write(f"R（召回率）: {mean_r:.3f}±{std_r:.3f}\n")
        f.write(f"mAP50: {mean_map50:.3f}±{std_map50:.3f}\n")
        f.write(f"mAP50-95: {mean_map50_95:.3f}±{std_map50_95:.3f}")


# 执行训练
if __name__ == "__main__":
    train_multiruns()