# 综合推理报告

- 更新日期: 2026-01-02

---

## Jetson 设备信息

- 采集命令: `jetson_release`

### 概要

- Jetpack: 6.2.1
- L4T: 36.4.7
- 硬件型号: NVIDIA Jetson Orin NX Engineering Reference Developer Kit
- 模块: NVIDIA Jetson Orin NX (16GB ram)
- P-Number: p3767-0000
- NV 电源模式: MAXN
- 序列号: [XXX]（显示：`jetson_release -s XXX`）

### 平台

- 操作系统: Ubuntu 22.04 Jammy Jellyfish
- 内核/版本: 5.15.148-tegra

### 软件与工具

- jetson-stats: 4.3.2
- jtop: 4.3.2（服务：Active）

### 主要库版本

- CUDA: 12.6.85
- cuDNN: 9.17.1.4
- TensorRT: 10.7.0.23
- VPI: 3.2.4
- Vulkan: 1.3.204
- OpenCV: 4.8.0（with CUDA: NO）

---

## 改进型模型（predict3）

- 模型路径: `./best/改进模型/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/改进模型/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.0 ms
  - 推理: 30.3 ms
  - 后处理: 2.4 ms
- 结果保存目录: `runs/detect/predict3`

---

## YOLOv8（predict4）

- 模型路径: `./best/YOLOv8/weights/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv8/weights/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.1 ms
  - 推理: 14.9 ms
  - 后处理: 2.4 ms
- 结果保存目录: `runs/detect/predict4`
- 参考文档: https://docs.ultralytics.com/modes/predict

---

## YOLOv10n（predict5）

- 模型路径: `./best/YOLOv10n/weights/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv10n/weights/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.0 ms
  - 推理: 18.5 ms
  - 后处理: 0.9 ms
- 结果保存目录: `runs/detect/predict5`

---

## RT-DETR（predict6）

- 模型路径: `./best/RT-DETR/weights/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/RT-DETR/weights/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 640, 640)
- 性能（每张图像）:
  - 预处理: 4.8 ms
  - 推理: 59.6 ms
  - 后处理: 1.4 ms
- 结果保存目录: `runs/detect/predict6`

---

## YOLOv8（predict8, engine）

- 模型路径: `./best/YOLOv8/weights/best.engine`
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv8/weights/best.engine source=./datasets/images/test
  ```
- 输入形状: (1, 3, 640, 640)
- 性能（每张图像）:
  - 预处理: 4.3 ms
  - 推理: 6.4 ms
  - 后处理: 2.5 ms
- 结果保存目录: `runs/detect/predict8`

---

## YOLOv10n（predict9, engine）

- 模型路径: `./best/YOLOv10n/weights/best.engine`
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv10n/weights/best.engine source=./datasets/images/test
  ```
- 输入形状: (1, 3, 640, 640)
- 性能（每张图像）:
  - 预处理: 4.3 ms
  - 推理: 7.3 ms
  - 后处理: 1.0 ms
- 结果保存目录: `runs/detect/predict9`

---

## YOLOv8（predict14, FP16 engine）

- 模型路径: `./best/YOLOv8/weights/best-fp16.engine`
- 精度: FP16
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv8/weights/best-fp16.engine source=./datasets/images/test
  ```
- 输入形状: (1, 3, 640, 640)
- 性能（每张图像）:
  - 预处理: 4.3 ms
  - 推理: 3.5 ms
  - 后处理: 2.7 ms
- 结果保存目录: `runs/detect/predict14`

---

## YOLOv10n（predict15, FP engine）

- 模型路径: `./best/YOLOv10n/weights/best-fp.engine`
- 精度: FP (engine)
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv10n/weights/best-fp.engine source=./datasets/images/test
  ```
- 输入形状: (1, 3, 640, 640)
- 性能（每张图像）:
  - 预处理: 4.3 ms
  - 推理: 4.0 ms
  - 后处理: 1.0 ms
- 结果保存目录: `runs/detect/predict15`

---

## 改进型模型（predict13, FP16 engine）

- 模型路径: `./best/改进模型/best-fp16.engine`
- 精度: FP16
- 运行命令:
  ```bash
  yolo predict model=./best/改进模型/best-fp16.engine source=./datasets/images/test
  ```
- 输入形状: (1, 3, 640, 640)
- 性能（每张图像）:
  - 预处理: 4.3 ms
  - 推理: 5.4 ms
  - 后处理: 2.7 ms
- 结果保存目录: `runs/detect/predict13`

---

## 模型性能对比

| 模型 | 模型路径 | 输入形状 | 预处理 (ms) | 推理 (ms) | 后处理 (ms) | 结果目录 | 运行命令 |
|---|---|:---:|---:|---:|---:|---|---|
| 改进型模型 (predict3) | `./best/改进模型/best.pt` | (1, 3, 512, 640) | 5.0 | 30.3 | 2.4 | `runs/detect/predict3` | `yolo predict model=./best/改进模型/best.pt source=./datasets/images/test` |
| YOLOv8 (predict4) | `./best/YOLOv8/weights/best.pt` | (1, 3, 512, 640) | 5.1 | 14.9 | 2.4 | `runs/detect/predict4` | `yolo predict model=./best/YOLOv8/weights/best.pt source=./datasets/images/test` |
| YOLOv10n (predict5) | `./best/YOLOv10n/weights/best.pt` | (1, 3, 512, 640) | 5.0 | 18.5 | 0.9 | `runs/detect/predict5` | `yolo predict model=./best/YOLOv10n/weights/best.pt source=./datasets/images/test` |
| RT-DETR (predict6) | `./best/RT-DETR/weights/best.pt` | (1, 3, 640, 640) | 4.8 | 59.6 | 1.4 | `runs/detect/predict6` | `yolo predict model=./best/RT-DETR/weights/best.pt source=./datasets/images/test` |
| 改进型模型 (predict7, engine) | `./best/改进模型/best.engine` | (1, 3, 640, 640) | 4.3 | 8.7 | 2.7 | `runs/detect/predict7` | `yolo predict model=./best/改进模型/best.engine source=./datasets/images/test` |
| YOLOv8 (predict8, engine) | `./best/YOLOv8/weights/best.engine` | (1, 3, 640, 640) | 4.3 | 6.4 | 2.5 | `runs/detect/predict8` | `yolo predict model=./best/YOLOv8/weights/best.engine source=./datasets/images/test` |
| YOLOv10n (predict9, engine) | `./best/YOLOv10n/weights/best.engine` | (1, 3, 640, 640) | 4.3 | 7.3 | 1.0 | `runs/detect/predict9` | `yolo predict model=./best/YOLOv10n/weights/best.engine source=./datasets/images/test` |
| 改进型模型 (predict13, fp16 engine) | `./best/改进模型/best-fp16.engine` | (1, 3, 640, 640) | 4.3 | 5.4 | 2.7 | `runs/detect/predict13` | `yolo predict model=./best/改进模型/best-fp16.engine source=./datasets/images/test` |
| YOLOv8 (predict14, fp16 engine) | `./best/YOLOv8/weights/best-fp16.engine` | (1, 3, 640, 640) | 4.3 | 3.5 | 2.7 | `runs/detect/predict14` | `yolo predict model=./best/YOLOv8/weights/best-fp16.engine source=./datasets/images/test` |
| YOLOv10n (predict15, fp engine) | `./best/YOLOv10n/weights/best-fp.engine` | (1, 3, 640, 640) | 4.3 | 4.0 | 1.0 | `runs/detect/predict15` | `yolo predict model=./best/YOLOv10n/weights/best-fp.engine source=./datasets/images/test` |


---

 内存使用：
./best/改进模型/best.engine | 6.7 GB
./best/YOLOv8/weights/best.engine | 6.8 GB
./best/YOLOv10n/weights/best.engine | 6.75 GB