# 综合推理报告（合并版）

- 更新日期: 2026-01-02

---

## 改进型模型（predict3）

- 模型路径: `./best/改进模型/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/改进模型/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.0 ms
  - 推理: 30.3 ms
  - 后处理: 2.4 ms
- 结果保存目录: `runs/detect/predict3`

---

## YOLOv8（predict4）

- 模型路径: `./best/YOLOv8/weights/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv8/weights/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.1 ms
  - 推理: 14.9 ms
  - 后处理: 2.4 ms
- 结果保存目录: `runs/detect/predict4`
- 参考文档: https://docs.ultralytics.com/modes/predict

---

单独报告文件路径：

- 改进型模型报告: [runs/detect/predict3/report.md](runs/detect/predict3/report.md)
- YOLOv8 报告: [runs/detect/predict4/report.md](runs/detect/predict4/report.md)

---

## YOLOv10n（predict5）

- 模型路径: `./best/YOLOv10n/weights/best.pt`
- 运行命令:
  ```bash
  yolo predict model=./best/YOLOv10n/weights/best.pt source=./datasets/images/test
  ```
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.0 ms
  - 推理: 18.5 ms
  - 后处理: 0.9 ms
- 结果保存目录: `runs/detect/predict5`

---

## 模型性能对比

| 模型 | 模型路径 | 输入形状 | 预处理 (ms) | 推理 (ms) | 后处理 (ms) | 结果目录 | 运行命令 |
|---|---|:---:|---:|---:|---:|---|---|
| 改进型模型 (predict3) | `./best/改进模型/best.pt` | (1,3,512,640) | 5.0 | 30.3 | 2.4 | `runs/detect/predict3` | `yolo predict model=./best/改进模型/best.pt source=./datasets/images/test` |
| YOLOv8 (predict4) | `./best/YOLOv8/weights/best.pt` | (1,3,512,640) | 5.1 | 14.9 | 2.4 | `runs/detect/predict4` | `yolo predict model=./best/YOLOv8/weights/best.pt source=./datasets/images/test` |
| YOLOv10n (predict5) | `./best/YOLOv10n/weights/best.pt` | (1,3,512,640) | 5.0 | 18.5 | 0.9 | `runs/detect/predict5` | `yolo predict model=./best/YOLOv10n/weights/best.pt source=./datasets/images/test` |

说明：表格按每张图像的时间（ms）对比推理开销；若需导出为 CSV/Excel，我可以生成对应文件。

