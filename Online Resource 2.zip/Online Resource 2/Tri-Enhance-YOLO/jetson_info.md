# Jetson 设备信息

- 采集命令: `jetson_release`
- 采集日期: 2026-01-02

## 概要

- Jetpack: 6.2.1
- L4T: 36.4.7
- 硬件型号: NVIDIA Jetson Orin NX Engineering Reference Developer Kit
- 模块: NVIDIA Jetson Orin NX (16GB ram)
- NV 电源模式: MAXN
- 序列号: [XXX]（显示：`jetson_release -s XXX`）

## 平台

- 操作系统: Ubuntu 22.04 Jammy Jellyfish
- 内核/版本: 5.15.148-tegra

## 软件与工具

- jetson-stats: 4.3.2
- jtop: 4.3.2（服务：Active）

## 主要库版本

- CUDA: 12.6.85
- cuDNN: 9.17.1.4
- TensorRT: 10.7.0.23
- VPI: 3.2.4
- Vulkan: 1.3.204
- OpenCV: 4.8.0（with CUDA: NO）

## 备注

- P-Number: p3767-0000
- 如需我将此文档追加到主合并报告或导出为 PDF/HTML/CSV，请告知。
