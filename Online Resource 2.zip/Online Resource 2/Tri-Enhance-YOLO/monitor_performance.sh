#!/bin/bash

# Jetson Orin NX 性能监控脚本 - 显示具体内存用量
# 使用方法: ./monitor_performance.sh --model <模型路径> [选项]

# 默认参数
MODEL_PATH="./best/RT-DETR/weights/best.pt"
SOURCE="./datasets/images/test"
IMGSZ=640
CONF=0.25
DEVICE="0"
VERBOSE="False"
MONITOR_INTERVAL=1000  # tegrastats 监控间隔(ms)
OUTPUT_DIR="./performance_logs"
LOG_PREFIX="performance"

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -m|--model)
            MODEL_PATH="$2"
            shift 2
            ;;
        -s|--source)
            SOURCE="$2"
            shift 2
            ;;
        -i|--imgsz)
            IMGSZ="$2"
            shift 2
            ;;
        -c|--conf)
            CONF="$2"
            shift 2
            ;;
        -d|--device)
            DEVICE="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE="True"
            shift
            ;;
        -o|--output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --interval)
            MONITOR_INTERVAL="$2"
            shift 2
            ;;
        -h|--help)
            echo "Jetson Orin NX 性能监控脚本"
            echo ""
            echo "使用方法: $0 [选项]"
            echo ""
            echo "选项:"
            echo "  -m, --model PATH     模型路径 (默认: $MODEL_PATH)"
            echo "  -s, --source PATH    输入源 (默认: $SOURCE)"
            echo "  -i, --imgsz SIZE     图像尺寸 (默认: $IMGSZ)"
            echo "  -c, --conf CONF      置信度阈值 (默认: $CONF)"
            echo "  -d, --device DEV     设备ID (默认: $DEVICE)"
            echo "  -v, --verbose        显示详细输出"
            echo "  -o, --output DIR     输出目录 (默认: $OUTPUT_DIR)"
            echo "  --interval MS        tegrastats监控间隔(ms) (默认: $MONITOR_INTERVAL)"
            echo "  -h, --help           显示此帮助信息"
            echo ""
            echo "示例:"
            echo "  $0 --model ./best.pt --source ./images --imgsz 640 --conf 0.5"
            echo "  $0 -m ./yolo11n.pt -s ./test -i 320 -v"
            exit 0
            ;;
        *)
            echo "未知参数: $1"
            echo "使用 -h 或 --help 查看帮助"
            exit 1
            ;;
    esac
done

# 检查模型文件是否存在
if [ ! -f "$MODEL_PATH" ]; then
    echo "错误: 模型文件不存在: $MODEL_PATH"
    echo "请检查路径是否正确"
    exit 1
fi

# 检查输入源是否存在
if [ ! -e "$SOURCE" ]; then
    echo "错误: 输入源不存在: $SOURCE"
    exit 1
fi

# 创建输出目录
mkdir -p "$OUTPUT_DIR"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="${OUTPUT_DIR}/${LOG_PREFIX}_${TIMESTAMP}.log"
TEGRA_LOG="${OUTPUT_DIR}/tegrastats_${TIMESTAMP}.log"
SUMMARY_FILE="${OUTPUT_DIR}/summary_${TIMESTAMP}.txt"
MEMORY_CSV="${OUTPUT_DIR}/memory_usage_${TIMESTAMP}.csv"

echo "=== Jetson Orin NX 性能监控 ===" | tee -a "$LOG_FILE"
echo "开始时间: $(date)" | tee -a "$LOG_FILE"
echo "模型: $MODEL_PATH" | tee -a "$LOG_FILE"
echo "输入源: $SOURCE" | tee -a "$LOG_FILE"
echo "图像尺寸: $IMGSZ" | tee -a "$LOG_FILE"
echo "置信度阈值: $CONF" | tee -a "$LOG_FILE"
echo "设备: $DEVICE" | tee -a "$LOG_FILE"
echo "输出目录: $OUTPUT_DIR" | tee -a "$LOG_FILE"
echo "日志文件: $LOG_FILE" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# 系统信息
echo "=== 系统信息 ===" | tee -a "$LOG_FILE"
echo "主机名: $(hostname)" | tee -a "$LOG_FILE"
echo "系统: $(uname -a)" | tee -a "$LOG_FILE"
echo "Python版本: $(python3 --version 2>/dev/null || echo '未安装')" | tee -a "$LOG_FILE"

# 获取总内存信息（一次获取，后续使用）
TOTAL_MEM_MB=$(free -m | awk '/^Mem:/ {print $2}')
TOTAL_MEM_GB=$(echo "scale=2; $TOTAL_MEM_MB / 1024" | bc)
echo "总内存: ${TOTAL_MEM_MB} MB (${TOTAL_MEM_GB} GB)" | tee -a "$LOG_FILE"

# 查看 GPU 状态
echo "" | tee -a "$LOG_FILE"
echo "=== GPU 状态 ===" | tee -a "$LOG_FILE"
if command -v jetson_clocks &> /dev/null; then
    sudo jetson_clocks --show | head -20 | tee -a "$LOG_FILE"
else
    echo "jetson_clocks 命令未找到" | tee -a "$LOG_FILE"
fi

# 查看温度
echo "" | tee -a "$LOG_FILE"
echo "=== 温度监控 ===" | tee -a "$LOG_FILE"
if [ -d "/sys/devices/virtual/thermal" ]; then
    for zone in /sys/devices/virtual/thermal/thermal_zone*; do
        if [ -f "$zone/temp" ]; then
            temp=$(cat "$zone/temp")
            type=$(cat "$zone/type" 2>/dev/null || echo "unknown")
            echo "$type: $(echo "scale=1; $temp/1000" | bc)°C" | tee -a "$LOG_FILE"
        fi
    done
else
    echo "无法读取温度信息" | tee -a "$LOG_FILE"
fi

# 查看内存使用 - 详细版本
echo "" | tee -a "$LOG_FILE"
echo "=== 内存使用详情 ===" | tee -a "$LOG_FILE"
free -h | tee -a "$LOG_FILE"

# 添加具体数值
echo "" | tee -a "$LOG_FILE"
echo "内存具体数值:" | tee -a "$LOG_FILE"
free -m | awk '
    /^Mem:/ {
        printf "  总内存: %d MB (%.1f GB)\n", $2, $2/1024
        printf "  已使用: %d MB (%.1f GB)\n", $3, $3/1024
        printf "  空闲: %d MB (%.1f GB)\n", $4, $4/1024
        printf "  缓冲/缓存: %d MB (%.1f GB)\n", $6, $6/1024
        printf "  可用: %d MB (%.1f GB)\n", $7, $7/1024
        printf "  使用率: %.1f%%\n", ($3/$2)*100
    }
' | tee -a "$LOG_FILE"

# 查看GPU显存信息
echo "" | tee -a "$LOG_FILE"
echo "=== GPU 显存信息 ===" | tee -a "$LOG_FILE"
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free --format=csv | tee -a "$LOG_FILE"
    
    # 获取具体的GPU显存数值
    GPU_MEM_INFO=$(nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv,nounits,noheader 2>/dev/null)
    if [ -n "$GPU_MEM_INFO" ]; then
        echo "GPU显存具体数值:" | tee -a "$LOG_FILE"
        echo "$GPU_MEM_INFO" | awk -F, '{
            total=$1; used=$2; free=$3;
            printf "  总显存: %d MB (%.1f GB)\n", total, total/1024
            printf "  已使用: %d MB (%.1f GB)\n", used, used/1024
            printf "  空闲显存: %d MB (%.1f GB)\n", free, free/1024
            printf "  显存使用率: %.1f%%\n", (used/total)*100
        }' | tee -a "$LOG_FILE"
    fi
else
    echo "nvidia-smi 命令未找到" | tee -a "$LOG_FILE"
fi

# 查看磁盘空间
echo "" | tee -a "$LOG_FILE"
echo "=== 磁盘空间 ===" | tee -a "$LOG_FILE"
df -h . | tee -a "$LOG_FILE"

echo "" | tee -a "$LOG_FILE"
echo "=== 开始性能监控 ===" | tee -a "$LOG_FILE"

# 获取测试图像数量
if [ -d "$SOURCE" ]; then
    IMAGE_COUNT=$(find "$SOURCE" -maxdepth 1 \( -name "*.jpg" -o -name "*.jpeg" -o -name "*.png" -o -name "*.bmp" \) | wc -l)
    echo "检测到 $IMAGE_COUNT 张测试图像" | tee -a "$LOG_FILE"
elif [ -f "$SOURCE" ]; then
    IMAGE_COUNT=1
    echo "单个文件测试" | tee -a "$LOG_FILE"
else
    IMAGE_COUNT=0
    echo "警告: 无法确定输入源类型" | tee -a "$LOG_FILE"
fi

# 后台启动 tegrastats 监控
echo "启动 tegrastats 监控 (间隔: ${MONITOR_INTERVAL}ms)..." | tee -a "$LOG_FILE"
echo "时间戳,总内存_MB,已使用_MB,空闲_MB,使用率_%" > "$MEMORY_CSV"
tegrastats --interval "$MONITOR_INTERVAL" > "$TEGRA_LOG" &
TEGRA_PID=$!
echo "tegrastats 进程ID: $TEGRA_PID" | tee -a "$LOG_FILE"

# 记录开始时间
START_TIME=$(date +%s)

# 运行预测任务
echo "" | tee -a "$LOG_FILE"
echo "=== 运行预测任务 ===" | tee -a "$LOG_FILE"
echo "开始时间: $(date)" | tee -a "$LOG_FILE"

if [ "$VERBOSE" = "True" ]; then
    yolo predict \
        model="$MODEL_PATH" \
        source="$SOURCE" \
        imgsz="$IMGSZ" \
        conf="$CONF" \
        device="$DEVICE" \
        save=False \
        verbose=True 2>&1 | tee -a "$LOG_FILE"
else
    yolo predict \
        model="$MODEL_PATH" \
        source="$SOURCE" \
        imgsz="$IMGSZ" \
        conf="$CONF" \
        device="$DEVICE" \
        save=False \
        verbose=False 2>&1 | tee -a "$LOG_FILE"
fi

# 记录结束时间
END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

echo "" | tee -a "$LOG_FILE"
echo "预测完成时间: $(date)" | tee -a "$LOG_FILE"
echo "总耗时: ${DURATION} 秒" | tee -a "$LOG_FILE"

# 停止监控
kill $TEGRA_PID 2>/dev/null
wait $TEGRA_PID 2>/dev/null
echo "tegrastats 监控已停止" | tee -a "$LOG_FILE"

# 性能统计
echo "" | tee -a "$LOG_FILE"
echo "=== 性能统计 ===" | tee -a "$LOG_FILE"

# 分析 tegrastats 日志 - 改进版，显示具体内存数值
if [ -f "$TEGRA_LOG" ]; then
    echo "分析 tegrastats 日志..." | tee -a "$LOG_FILE"
    
    # 处理tegrastats日志，提取具体内存数值
    echo "处理内存数据..." | tee -a "$LOG_FILE"
    awk -v total_mb="$TOTAL_MEM_MB" '
    /RAM [0-9]*\/[0-9]*MB/ {
        # 提取RAM使用情况: RAM 5475/15656MB
        match($0, /RAM ([0-9]+)\/([0-9]+)MB/, arr);
        if (arr[1] && arr[2]) {
            used_mb = arr[1];
            # total_mb = arr[2];  # 使用传入的总内存值
            timestamp = strftime("%H:%M:%S");
            
            # 计算百分比
            usage_percent = (used_mb / total_mb) * 100;
            
            # 输出到CSV
            printf "%s,%d,%d,%d,%.1f\n", 
                timestamp, total_mb, used_mb, total_mb - used_mb, usage_percent;
            
            # 存储用于统计
            sum_used += used_mb;
            count++;
            if (used_mb > max_used) max_used = used_mb;
            if (count == 1 || used_mb < min_used) min_used = used_mb;
        }
    }
    END {
        if (count > 0) {
            avg_used = sum_used / count;
            printf "MEMORY_STATS,%.1f,%.1f,%.1f,%.1f\n", 
                avg_used, max_used, min_used, (avg_used / total_mb) * 100;
        }
    }
    ' "$TEGRA_LOG" > temp_memory_stats.csv
    
    # 提取并显示内存统计
    if [ -f "temp_memory_stats.csv" ] && [ -s "temp_memory_stats.csv" ]; then
        # 读取统计行
        stats_line=$(grep "^MEMORY_STATS" temp_memory_stats.csv)
        
        if [ -n "$stats_line" ]; then
            IFS=',' read -r label avg_used max_used min_used avg_percent <<< "$stats_line"
            
            echo "" | tee -a "$LOG_FILE"
            echo "内存使用统计 (具体数值):" | tee -a "$LOG_FILE"
            echo "  平均使用: $(echo "scale=1; $avg_used" | bc) MB ($(echo "scale=1; $avg_used/1024" | bc) GB)" | tee -a "$LOG_FILE"
            echo "  峰值使用: $(echo "scale=1; $max_used" | bc) MB ($(echo "scale=1; $max_used/1024" | bc) GB)" | tee -a "$LOG_FILE"
            echo "  最低使用: $(echo "scale=1; $min_used" | bc) MB ($(echo "scale=1; $min_used/1024" | bc) GB)" | tee -a "$LOG_FILE"
            echo "  波动范围: $(echo "scale=1; $max_used - $min_used" | bc) MB" | tee -a "$LOG_FILE"
            echo "  平均使用率: $(echo "scale=1; $avg_percent" | bc)%" | tee -a "$LOG_FILE"
            
            # 显示内存使用趋势
            echo "" | tee -a "$LOG_FILE"
            echo "内存使用趋势 (采样点):" | tee -a "$LOG_FILE"
            head -5 temp_memory_stats.csv | grep -v "^MEMORY_STATS" | while IFS=',' read -r timestamp total used free percent; do
                echo "  $timestamp: ${used} MB (${percent}%)" | tee -a "$LOG_FILE"
            done
            
            if [ $(wc -l < temp_memory_stats.csv) -gt 8 ]; then
                echo "  ..." | tee -a "$LOG_FILE"
                tail -3 temp_memory_stats.csv | grep -v "^MEMORY_STATS" | while IFS=',' read -r timestamp total used free percent; do
                    echo "  $timestamp: ${used} MB (${percent}%)" | tee -a "$LOG_FILE"
                done
            fi
            
            # 保存详细内存数据到CSV
            grep -v "^MEMORY_STATS" temp_memory_stats.csv >> "$MEMORY_CSV"
        fi
        
        rm -f temp_memory_stats.csv
    else
        echo "无法提取内存统计数据" | tee -a "$LOG_FILE"
    fi
    
    # GPU 使用率统计
    echo "" | tee -a "$LOG_FILE"
    echo "GPU 使用率统计:" | tee -a "$LOG_FILE"
    gpu_stats=$(grep -o "GR3D [0-9]*%" "$TEGRA_LOG" | sed 's/GR3D //g; s/%//g' | awk '
        {
            sum+=$1; 
            count++; 
            if(max<$1) max=$1; 
            if(NR==1) min=$1; 
            if(min>$1) min=$1;
            values[count]=$1;
        } 
        END {
            if(count>0) {
                printf "  平均: %.1f%%\n", sum/count;
                printf "  最高: %.1f%%\n", max;
                printf "  最低: %.1f%%\n", min;
                
                # 计算中位数
                asort(values);
                if(count%2==1) {
                    median=values[int((count+1)/2)];
                } else {
                    median=(values[count/2] + values[count/2+1])/2;
                }
                printf "  中位数: %.1f%%\n", median;
            } else {
                print "  无GPU使用率数据";
            }
        }')
    echo "$gpu_stats" | tee -a "$LOG_FILE"
    
    # CPU 使用率统计
    echo "" | tee -a "$LOG_FILE"
    echo "CPU 使用率统计:" | tee -a "$LOG_FILE"
    grep -o "CPU \[[0-9]*%" "$TEGRA_LOG" | sed 's/CPU \[//g; s/%//g' | \
        awk '{
            sum+=$1; 
            count++; 
            if(max<$1) max=$1; 
            if(NR==1) min=$1; 
            if(min>$1) min=$1
        } 
        END {
            if(count>0) {
                printf "  平均: %.1f%%\n", sum/count;
                printf "  最高: %.1f%%\n", max;
                printf "  最低: %.1f%%\n", min;
            }
        }' | tee -a "$LOG_FILE"
    
    # 温度统计
    echo "" | tee -a "$LOG_FILE"
    echo "温度统计:" | tee -a "$LOG_FILE"
    grep -o "AO [0-9]*C" "$TEGRA_LOG" 2>/dev/null | sed 's/AO //g; s/C//g' | \
        awk '{
            sum+=$1; 
            count++; 
            if(max<$1) max=$1; 
            if(NR==1) min=$1; 
            if(min>$1) min=$1
        } 
        END {
            if(count>0) {
                printf "  平均温度: %.1f°C\n", sum/count;
                printf "  最高温度: %.1f°C\n", max;
                printf "  最低温度: %.1f°C\n", min;
            } else {
                print "  无温度数据";
            }
        }' | tee -a "$LOG_FILE"
    
else
    echo "tegrastats 日志文件不存在或为空" | tee -a "$LOG_FILE"
fi

# 计算FPS和性能指标
if [ $IMAGE_COUNT -gt 0 ] && [ $DURATION -gt 0 ]; then
    FPS=$(echo "scale=2; $IMAGE_COUNT / $DURATION" | bc)
    MS_PER_FRAME=$(echo "scale=2; 1000 / $FPS" | bc)
    
    echo "" | tee -a "$LOG_FILE"
    echo "性能摘要:" | tee -a "$LOG_FILE"
    echo "  处理图像数量: $IMAGE_COUNT" | tee -a "$LOG_FILE"
    echo "  总耗时: ${DURATION} 秒" | tee -a "$LOG_FILE"
    echo "  平均FPS: $FPS" | tee -a "$LOG_FILE"
    echo "  每帧平均时间: ${MS_PER_FRAME} ms" | tee -a "$LOG_FILE"
    
    # 计算吞吐量
    THROUGHPUT=$IMAGE_COUNT
    echo "  吞吐量: ${THROUGHPUT} 图像" | tee -a "$LOG_FILE"
    
    # 如果知道功耗，可以计算能效
    # echo "  能效: X 图像/焦耳" | tee -a "$LOG_FILE"
fi

# 最终内存状态（对比初始状态）
echo "" | tee -a "$LOG_FILE"
echo "=== 最终内存状态 ===" | tee -a "$LOG_FILE"
echo "当前内存使用:" | tee -a "$LOG_FILE"
free -m | awk '
    /^Mem:/ {
        printf "  总内存: %d MB (%.1f GB)\n", $2, $2/1024
        printf "  已使用: %d MB (%.1f GB)\n", $3, $3/1024
        printf "  空闲: %d MB (%.1f GB)\n", $4, $4/1024
        printf "  使用率: %.1f%%\n", ($3/$2)*100
    }
' | tee -a "$LOG_FILE"

# 生成摘要文件
{
    echo "=== 性能监控摘要 ==="
    echo "模型: $MODEL_PATH"
    echo "输入源: $SOURCE"
    echo "图像尺寸: $IMGSZ"
    echo "开始时间: $(date -d @$START_TIME)"
    echo "结束时间: $(date -d @$END_TIME)"
    echo "总耗时: ${DURATION} 秒"
    echo "处理图像数量: $IMAGE_COUNT"
    
    if [ $IMAGE_COUNT -gt 0 ] && [ $DURATION -gt 0 ]; then
        echo "FPS: $FPS"
        echo "每帧时间: ${MS_PER_FRAME} ms"
    fi
    
    # 内存摘要
    if [ -n "$avg_used" ]; then
        echo ""
        echo "内存使用摘要:"
        echo "  平均使用: ${avg_used} MB"
        echo "  峰值使用: ${max_used} MB"
        echo "  最低使用: ${min_used} MB"
        echo "  波动范围: $(echo "$max_used - $min_used" | bc) MB"
    fi
    
    echo ""
    echo "日志文件: $LOG_FILE"
    echo "tegrastats日志: $TEGRA_LOG"
    echo "内存使用CSV: $MEMORY_CSV"
    echo "性能摘要: $SUMMARY_FILE"
} > "$SUMMARY_FILE"

echo "" | tee -a "$LOG_FILE"
echo "=== 监控完成 ===" | tee -a "$LOG_FILE"
echo "详细日志: $LOG_FILE" | tee -a "$LOG_FILE"
echo "tegrastats原始日志: $TEGRA_LOG" | tee -a "$LOG_FILE"
echo "内存使用CSV数据: $MEMORY_CSV" | tee -a "$LOG_FILE"
echo "性能摘要: $SUMMARY_FILE" | tee -a "$LOG_FILE"
echo "结束时间: $(date)" | tee -a "$LOG_FILE"

# 显示CSV文件内容预览
echo "" | tee -a "$LOG_FILE"
echo "内存使用CSV预览 (前5行):" | tee -a "$LOG_FILE"
head -6 "$MEMORY_CSV" | tee -a "$LOG_FILE"