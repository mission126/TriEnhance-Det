# 改进型模型 推理报告

- 日期: 2026-01-02
- 模型: 改进型模型 (`./best/改进模型/best.pt`)
- 运行命令:
  `yolo predict model=./best/改进模型/best.pt source=./datasets/images/test`
- 输入形状: (1, 3, 512, 640)
- 性能（每张图像）:
  - 预处理: 5.0 ms
  - 推理: 30.3 ms
  - 后处理: 2.4 ms
- 结果保存目录: `runs/detect/predict3`
- 说明: 推理结果已保存到上面目录，若需将报告合并到 README 或导出为 PDF/HTML，请告知。
