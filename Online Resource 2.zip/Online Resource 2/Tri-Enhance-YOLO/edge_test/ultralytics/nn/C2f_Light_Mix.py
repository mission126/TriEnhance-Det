import torch
import torch.nn as nn
from ultralytics.nn.modules.conv import autopad, Conv

__all__ = ['C2f_Light_Mix']

# ------------------------------ 核心子模块（轻量化设计）------------------------------
class Light_ODConv(nn.Module):
    """轻量化动态注意力卷积：简化ODConv，保留核心动态权重调整，移除冗余分支"""
    def __init__(self, c1, c2, k=3, g=1):
        super().__init__()
        self.c1, self.c2 = c1, c2
        self.groups = g
        self.kernel_size = k
        self.padding = autopad(k)
        
        # 简化注意力：仅保留通道注意力（计算量低，效果显著）
        self.attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            Conv(c1, c1//4, 1, act=nn.ReLU()),
            Conv(c1//4, c2, 1, act=nn.Sigmoid())
        )
        
        # 动态权重卷积（分组卷积进一步轻量化）
        self.conv = nn.Conv2d(c1, c2, k, 1, self.padding, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU()

    def forward(self, x):
        # 动态注意力调整特征
        attn = self.attn(x)  # (B, C2, 1, 1)
        x_weighted = x * attn.expand_as(x)[:,:self.c1]  # 通道对齐
        # 分组卷积提取特征
        out = self.act(self.bn(self.conv(x_weighted)))
        return out

class Light_DWR(nn.Module):
    """轻量化多尺度感受野模块：简化DWR，保留3个 dilation 分支，减少通道冗余"""
    def __init__(self, c):
        super().__init__()
        self.c_split = c // 2  # 通道拆分，降低计算量
        # 3个不同 dilation 分支（感受野分别为3、7、11）
        self.conv_d1 = Conv(self.c_split, self.c_split, 3, d=1)  # 普通3x3
        self.conv_d3 = Conv(self.c_split, self.c_split, 3, d=3)  #  dilation=3
        self.conv_d5 = Conv(self.c_split, self.c_split, 3, d=5)  #  dilation=5
        # 特征融合（1x1降维，避免通道爆炸）
        self.conv_fuse = Conv(self.c_split * 3, c, 1)

    def forward(self, x):
        # 通道拆分：前半部分走多尺度分支，后半部分保留原始特征
        x1, x2 = x.chunk(2, dim=1)  # (B, c_split, H, W) * 2
        # 多尺度特征提取
        d1 = self.conv_d1(x1)
        d3 = self.conv_d3(x1)
        d5 = self.conv_d5(x1)
        # 融合+残差连接
        fuse = self.conv_fuse(torch.cat([d1, d3, d5], dim=1))
        return fuse + x  # 残差连接，稳定训练

class Channel_Shuffle(nn.Module):
    """通道重排：打破通道分组限制，提升特征交互（计算量可忽略）"""
    def __init__(self, groups=2):
        super().__init__()
        self.groups = groups

    def forward(self, x):
        B, C, H, W = x.shape
        c_per_group = C // self.groups
        # 分组->转置->合并
        x = x.view(B, self.groups, c_per_group, H, W)
        x = torch.transpose(x, 1, 2).contiguous()
        x = x.view(B, -1, H, W)
        return x

# ------------------------------ 主模块（C2f-Light-Mix）------------------------------
class Bottleneck_Light_Mix(nn.Module):
    """轻量化瓶颈块：融合 Light_ODConv + Light_DWR + Channel_Shuffle"""
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):
        super().__init__()
        self.c = int(c2 * e)  # 隐藏层通道数（压缩率0.5，轻量化）
        self.cv1 = Conv(c1, self.c, 1)  # 1x1降维
        # 核心融合分支：注意力->多尺度->通道重排
        self.mix = nn.Sequential(
            Light_ODConv(self.c, self.c, g=g),  # 动态注意力筛选特征
            Light_DWR(self.c),                  # 多尺度感受野增强
            Channel_Shuffle(groups=2)           # 通道重排提升交互
        )
        self.cv2 = Conv(self.c, c2, 1)  # 1x1升维
        self.add = shortcut and c1 == c2  # 残差连接条件

    def forward(self, x):
        out = self.cv2(self.mix(self.cv1(x)))
        return x + out if self.add else out

class C2f_Light_Mix(nn.Module):
    """最终模块：C2f框架 + 轻量化融合瓶颈块"""
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1)  # 拆分2路
        self.cv2 = Conv((2 + n) * self.c, c2, 1)  # 最终融合
        # 堆叠n个轻量化融合瓶颈块
        self.m = nn.ModuleList(
            Bottleneck_Light_Mix(self.c, self.c, shortcut, g, e=1.0) for _ in range(n)
        )

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))  # 拆分2路：y[0]直接保留，y[1]进瓶颈块
        y.extend(m(y[-1]) for m in self.m)  # 堆叠瓶颈块输出
        return self.cv2(torch.cat(y, 1))  # 所有特征融合

    def forward_split(self, x):
        y = list(self.cv1(x).split((self.c, self.c), 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))